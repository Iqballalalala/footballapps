package com.omrobbie.footballapps.model

data class LeagueResponse(val leagues: MutableList<LeaguesItem>)
