package com.omrobbie.footballapps.model

data class EventResponse(val events: MutableList<EventsItem>)
