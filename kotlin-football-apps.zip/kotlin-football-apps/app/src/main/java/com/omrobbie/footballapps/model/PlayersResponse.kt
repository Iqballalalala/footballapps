package com.omrobbie.footballapps.model

data class PlayersResponse(val player: MutableList<PlayersItem>)
