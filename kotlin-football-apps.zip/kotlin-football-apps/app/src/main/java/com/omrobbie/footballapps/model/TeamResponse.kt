package com.omrobbie.footballapps.model

data class TeamResponse(val teams: MutableList<TeamsItem>)
