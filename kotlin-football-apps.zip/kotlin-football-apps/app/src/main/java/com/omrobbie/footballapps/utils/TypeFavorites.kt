package com.omrobbie.footballapps.utils

enum class TypeFavorites {
    MATCHES, TEAMS
}
