package com.omrobbie.footballapps.utils

enum class TypeMatches {
    NEXT, LAST
}
